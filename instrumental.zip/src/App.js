import logo from './logo.svg';
import './App.css';
import Dashboard from './Components/Layout/Dashboard';

function App() {
  return (
    <div>
    <Dashboard/>
    </div>
  );
}

export default App;
